import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'package:myapp/src/pages/entry_point/page.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();

  Supabase.initialize(
    url:
        'https://drive.google.com/file/d/1WBTxU6zfZn1CRaXUsjnUNorEYw0Zczp-/view',
    anonKey: '',
  );

  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Reveal Sense',
      home: PageEntryPoint(),
    );
  }
}
